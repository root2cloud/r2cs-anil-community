# -*- encoding: utf-8 -*-

from . import patient_barcode_wizard

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: