# -*- coding: utf-8 -*-

from . import product

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
