# -*- coding: utf-8 -*-

from . import waiting_screen
