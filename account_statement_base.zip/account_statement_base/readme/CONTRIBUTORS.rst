* `Akretion <https://www.akretion.com>`_:

  * Alexis de Lattre <alexis.delattre@akretion.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Carlos Dauden
  * Sergio Teruel

* `ForgeFlow <https://www.forgeflow.com>`_:

  * Jordi Ballester
