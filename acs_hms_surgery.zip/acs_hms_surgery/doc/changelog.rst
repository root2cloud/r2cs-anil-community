`1.0.9                                                        [02/08/2023]`
***************************************************************************
- Improved code for set hospital invoice type in invoice.

`1.0.8                                                        [20/06/2023]`
***************************************************************************
- Update code for create invoice pass product UOM.

`1.0.7                                                        [27/05/2023]`
***************************************************************************
- Added changes to create common invoice from appointment

`1.0.6                                                        [19/05/2023]`
***************************************************************************
- Added code for status widget on status in list view.

`1.0.5                                                       [02/02/2023]`
***************************************************************************
- Improved code for linking the physician to commission partner on invoice

`1.0.4                                                        [23/12/2022]`
***************************************************************************
- Imprvoed code for smart button on invoices.

`1.0.3                                                        [11/11/2022]`
***************************************************************************
- Improved access rights.
1> User: can see and create surgery
2> Approver: can confirm and makr as done all surgey
3> manager can update masters.

`1.0.2                                                        [11/11/2022]`
***************************************************************************
- Added packge option.

`1.0.1                                                        [11/10/2022]`
***************************************************************************
- Launched Module for v16