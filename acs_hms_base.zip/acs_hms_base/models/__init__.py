# -*- coding: utf-8 -*-

from . import hms_mixin
from . import hms_base
from . import hms_consumable_line
from . import partner
from . import patient
from . import physician
from . import product
from . import drug
from . import account
from . import ir_sequence
from . import res_config
from . import stock_move

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: