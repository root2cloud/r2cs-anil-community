# -*- encoding: utf-8 -*-

from . import hospital_base
from . import hms_base
from . import res_config_settings
from . import death_register
from . import hospitalization
from . import hospitalization_care
from . import digest


# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: