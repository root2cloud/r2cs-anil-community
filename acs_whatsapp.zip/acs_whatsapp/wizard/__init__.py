# -*- encoding: utf-8 -*-

from . import create_whatsapp_message
from . import whatsapp_messages

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
