# -*- encoding: utf-8 -*-

from . import whatsapp_template
from . import message
from . import announcement
from . import partner
from . import company

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4: